const orderBy = require('lodash.orderby');

const start = async (payload) => {
    console.log(`algorithm: start`);
    const [array, order] = payload.input;
    const afterOrder = orderBy(array,order, null );
    console.log(`order :` + order);
    console.log(`array :` + array);
    console.log(`result :` + afterOrder);
    return {result:{sorted:afterOrder,inputArray:array,inputOrder:order}};
}

module.exports = {
    start
}
