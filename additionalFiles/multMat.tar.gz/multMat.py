import numpy as np


def start(args):
    mat = args["input"][0]
    num = args["input"][1]
    return np.multiply(mat,num)


# inp = {
#     "input": [[np.array([1, 2, 3])], 3]
# }
#
# print(start(inp))
