import time

import os



def start(args, hkubeapi):


    return {"name": "python test",

            "version": "v2",
            "input": args["input"]
            }

