import numpy as np


def start(args):
    return np.eye(args["input"][0]).tolist()


# inp = {
#     "input": [3]
# }
#
# print(start(inp))
