def start(args):
    inp = args["input"]
    add_sum = 0
    for i in range(len(inp)):
        add_sum = add_sum + inp[i]

    return add_sum

# arg = {"input": [
#     5, 2, 5, 20
# ]}
#
# print(start(arg))
