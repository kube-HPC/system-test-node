def start(args):
    inp = args["input"]
    add_sum = 1
    for i in range(len(inp)):
        add_sum = add_sum / inp[i]

    return add_sum

# arg = {"input": [
#     1, 0.5, 0.25, 0.6
# ]}
#
# print(start(arg))
